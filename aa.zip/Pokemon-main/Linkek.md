Tutorial  
https://www.wikihow.com/Play-With-Pok%C3%A9mon-Cards

Játékszabályok és segítség
https://drive.google.com/file/d/1gLxGxMP4TIkLoBAf5zLSbui3UKvtYYwF/view

Base set kártyák  
https://bulbapedia.bulbagarden.net/wiki/Base_Set_(TCG),  
https://www.digitaltq.com/pokemon-tcg/base-set

Kész deckek  
https://bulbapedia.bulbagarden.net/wiki/My_First_Battle_(TCG) - My first battle (egyszerusitett cuccok)  
https://www.cardmarket.com/en/Pokemon/Products/Theme-Decks - Prebuilt deckek  
https://pokemoncard.io/deck-search/?&name=base&offset=0,  
https://pokemoncard.io/category/format/unlimited/

<3
